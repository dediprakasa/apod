# apod
This app might look simple outside, but it actually implemented advanced topics like clean architecture with VIPER, reactive programming with Combine, and Continous Integration (CI) with Travis CI.

# Demo
![](demo.gif)
