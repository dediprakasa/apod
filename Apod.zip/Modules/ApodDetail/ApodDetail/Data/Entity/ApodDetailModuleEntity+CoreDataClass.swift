//
//  ApodDetailModuleEntity+CoreDataClass.swift
//  ApodDetail
//
//  Created by Dedi Prakasa on 2/4/21.
//
//

import Foundation
import CoreData

@objc(ApodDetailModuleEntity)
public class ApodDetailModuleEntity: NSManagedObject {

}
