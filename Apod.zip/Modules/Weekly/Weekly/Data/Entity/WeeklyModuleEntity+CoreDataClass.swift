//
//  WeeklyModuleEntity+CoreDataClass.swift
//  
//
//  Created by Dedi Prakasa on 2/2/21.
//
//

import Foundation
import CoreData

@objc(WeeklyModuleEntity)
public class WeeklyModuleEntity: NSManagedObject {

}
