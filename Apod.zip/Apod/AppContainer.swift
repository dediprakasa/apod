//
//  AppContainer.swift
//  Apod
//
//  Created by Dedi Prakasa on 11/30/20.
//

import SwiftUI

class AppContainer {

    private let remoteDataSource = RemoteDataSource.sharedInstance
    private let localeDataSource = LocalDataSource.sharedInstance

    private lazy var repository = ApodRepository.sharedInstance(remoteDataSource, localeDataSource)
    private lazy var homeInteractor = HomeInteractor(repository: repository)
    private lazy var detailInteractor = DetailInteractor(repository: repository)
    private lazy var favoriteInteractor = FavoriteInteractor(repository: repository)

    private lazy var homeRouter = HomeRouter()
    private lazy var favoriteRouter = FavoriteRouter()

    lazy var homePresenter = HomePresenter(useCase: homeInteractor, router: homeRouter)
    lazy var detailPresenter = DetailPresenter(detailUseCase: detailInteractor)
    lazy var favoritePresenter = FavoritePresenter(useCase: favoriteInteractor, router: favoriteRouter)
}
